#pragma once

enum class Status
{
	Recorded = 0,
	Interrpted,
	Greduate,
	Empty,
};


