#include "Student.h"
#include "Subject.h"
#include "Grade.h"
#include <iostream>

using namespace std;

int main()
{


	return 0;
}