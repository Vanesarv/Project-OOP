#pragma once

enum class Course
{
	Empty = 0,
	FirstYear,
	SecondYear,
	ThirdYear,
	FourthYear,
};
