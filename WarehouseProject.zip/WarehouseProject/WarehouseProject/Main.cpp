#include <iostream>
#include "Product.h"
#include "Date.h"
#include "Location.h"
using namespace std;

int main()
{



	return 0;
}